class Subscription {
  String name;
  int price;
  int payDay;
  String paymentMethod;

  Subscription({
    required this.name,
    required this.price,
    required this.payDay,
    required this.paymentMethod,
  });
}
